package br.edu.fatecpg.model;

public interface OperacaoMatematica {

	
	double somar(double a,double b);
	double subtrair(double a,double b);
	double multiplicar(double a,double b);
	double dividir(double a,double b);
	
	
}