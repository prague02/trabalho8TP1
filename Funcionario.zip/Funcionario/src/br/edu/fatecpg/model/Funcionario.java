package br.edu.fatecpg.model;

public interface Funcionario {

	public  void baterPonto();
	public  void solicitarMaterial();
	
	
}