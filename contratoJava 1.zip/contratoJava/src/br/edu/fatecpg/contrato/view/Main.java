package br.edu.fatecpg.contrato.view;
import br.edu.fatecpg.contrato.model.*;

public class Main {

	public static void main(String[] args) {
		
		Faxineiro faxineiro = new Faxineiro();
		
		faxineiro.baterPonto();
		
		Gerente gerente = new Gerente();
		
		gerente.fecharCaixa();
		
		Vendedor vendedor = new Vendedor();
		
		vendedor.realizarVenda();

	}

}
