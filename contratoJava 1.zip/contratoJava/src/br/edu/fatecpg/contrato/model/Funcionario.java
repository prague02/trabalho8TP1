package br.edu.fatecpg.contrato.model;

public interface Funcionario {

	public void baterPonto();
	public void solitarMaterial();
}
