package br.edu.fatecpg.contrato.model;

public class Faxineiro implements Funcionario{

	@Override
	public void baterPonto() {
		System.out.println("Ponto registrado.");
		
	}

	@Override
	public void solitarMaterial() {
		System.out.println("Qual o material?");
	}

}
